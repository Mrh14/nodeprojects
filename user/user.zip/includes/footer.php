
<script>
    $('document').ready(function(){
$('#datatable').DataTable({
"language": {
"url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/French.json"
}
});


});
</script>
<footer class="footer">
    © 2020 <b>Visio </b> <span class="d-none d-sm-inline-block"> - création et conception <i class="mdi mdi-heart text-danger"></i> Agence digitale FCPO.</span>
</footer>