<?php

exit("<script type=\"text/javascript\">window.location.replace(\"reservations\");</script>");

?>