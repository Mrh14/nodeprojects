<footer class="footer">
    © 2020 <b>Digital DATA</b> <span class="d-none d-sm-inline-block"> - création et conception <i class="mdi mdi-heart text-danger"></i> Agence digitale FCPO.</span>
</footer>